##from PList.models import Barangay, TravelerProfile, Trequest, Requirements, Status
 #Register your models here.
#admin.site.register(Barangay)
#admin.site.register(TravelerProfile)
#admin.site.register(Trequest)
#admin.site.register(Requirements)
#admin.site.register(Status)