from .models import Barangay, TravelerProfile
from django.contrib import admin
 # Register your models here.
admin.site.register(Barangay)
admin.site.register(TravelerProfile)
#admin.site.register(Trequest)
#admin.site.register(Requirements)
#admin.site.register(Status)
