from django.db import models

'''Gender_CHOICES = (
   ('Male', 'Male'),
   ('Female', 'Female')
)'''

class Barangay(models.Model):
	Tname = models.TextField(max_length=50, default="")
	birthday = models.CharField(max_length=10, )
	gender = models.TextField(max_length=10, default="")
	address = models.CharField(max_length=50, default="")
	cnumber = models.CharField(max_length=11,default=None)
	email = models.CharField(max_length=50, null=True)
	class meta:
		db_table = "vbarangay"


class Trequest(models.Model):

	# travelprofile = models.ForeignKey(TravelerProfile, on_delete=models.CASCADE)
	departuredate = models.DateField(max_length=12, default="")
	returndate = models.DateField(max_length=12, default="")
	destinationtravel = models.CharField(max_length=50, default="")
	class meta:
		db_table = "trequest"


class Requirements(models.Model):
	Swabresult_CHOICES = (
  	('Negative', 'negative'),
  	('Positive', 'positive'),)

	Transportations = (
 	('Public', 'public'),
 	('Private', 'private'),)
	
	# Travelprofile = models.(TravelerProfile, on_delete=models.CASCADE)
	swabresult = models.CharField(max_length=50, default=None, choices=Swabresult_CHOICES)
	RidtCard= models.CharField(max_length=100, null=True)
	identificationCards = models.FileField(upload_to='documents/' ,null=True)
	Rtranspo= models.CharField(max_length=100, null=True)
	transportation = models.CharField(max_length=50, default=None, choices=Transportations)
	class meta:
		db_table = "trequirements"




